const fs = require('fs')
const chalk = require('chalk')

// Change The Bot Info
global.botName = "ṡṭяѧṿѧɞȏṭẓ"
global.ownerName = "ʟɛƈƈʏօʄƈ"
global.ownerNumber = ["628XXXXXXX"] 

global.Auto_Typing = false // auto typing
global.Auto_ReadPesan = false // auto read
global.Auto_Recording = false // auto recording
global.Auto_SendBug = true // auto ngirim bug ke nomor

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})